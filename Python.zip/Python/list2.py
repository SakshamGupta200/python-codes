name=[]
n=int(input("enter your length="))
for i in range(1,n+1):
    name.append(input("enter name"))
for i in name:
    print(i)
