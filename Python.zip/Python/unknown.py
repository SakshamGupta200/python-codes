a=input("enter your first name")
b=input("enter your last name")
print(a[0],b[0])

