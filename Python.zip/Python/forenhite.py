a=int(input("inter forenhite"))
c=a-32
c=5*c
d=c/9
print("celcious=",d)
