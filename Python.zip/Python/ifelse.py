n=int(input("enter your number"))
if n%2==0:
    print("even number")
else:
    print("odd number")
