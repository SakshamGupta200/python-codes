a=input("enter your first name")
for i=0 i<'\0' i++
{
    if(i=='\0')
    {
        j++
    }
}


