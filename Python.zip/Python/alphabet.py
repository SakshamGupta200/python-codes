#a=int(input("enter your number"))
for i in range(65,92):
   
    print( chr(i))

