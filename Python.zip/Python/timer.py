a=int(input("enter ammount"))
h2=int(a/2000)
a=a%2000
m5=int(a/500)
a=a%500
s2=int(a/200)
a=a%200
b1=a%100
print("h=",h,"m=",m,"s=",s)

