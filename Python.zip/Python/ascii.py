a=input("enter your number")
print(ord(a))
