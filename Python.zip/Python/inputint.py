a=int(input("enter length no"))
b=int(input("enter base no"))
c=a*b
d=2*(a+b)
print("area=%d"%c)

print("parimeter=",d)

