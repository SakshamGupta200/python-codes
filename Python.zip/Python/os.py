import os
os.rename("D:\\ram.txt","D:\\ram1.txt")
print("file rename")
    
