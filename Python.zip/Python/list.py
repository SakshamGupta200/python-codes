name=["rohit","komal","pankaj","sunil"]
print(type(name))
print(name)
