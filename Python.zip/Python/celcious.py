a=int(input("inter celcious"))
a=a*9
c=a/5
d=c+32
print("forenhite=",d)
