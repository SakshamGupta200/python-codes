#tuples() "immutable"
t1=("ram","komal","sunny")
t2=(10,20,30,"rohit",30.2)
t3=10,20,30,"rohit"
print(type(t1))
print(type(t2))
print(type(t3))
print(t1)
print(t2)
print(t3)
