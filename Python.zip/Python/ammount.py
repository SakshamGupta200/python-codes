a=int(input("enter ammount"))
h2=int(a/2000)
a=a%2000
m5=int(a/500)
a=a%500
s2=int(a/200)
a=a%200
b1=int(a/100)
print("2000=",h2,"500=",m5,"200=",s2,"100=",b1)

