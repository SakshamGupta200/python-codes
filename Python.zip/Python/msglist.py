list1=[]
n=input("enter your msg=")
st=n.split(" ")
for i in st:
    list1.append(i)
    
    
       
print(list1)

        
