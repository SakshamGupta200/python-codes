num={}
print(type(num))
num1=set([])
print(type(num1))
