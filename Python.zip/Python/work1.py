n=int(input("enter your number"))
for i in range(0,n+1):
    for j in range(0,n+1):
        
        print(i,end="")
        
        print(j,end="")
        print(end=" ")
                
   
    print("")
