num=set([1,2,3,4])

num.update([5,6,6,7,8,9])
print(num)
