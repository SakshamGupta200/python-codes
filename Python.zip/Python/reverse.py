#a=int(input("enter your number"))
for i in range(65,91):
    chr(i)
    print(i)

