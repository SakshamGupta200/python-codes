a=int(input("enter your number"))
for i in range(1,11):
    b=a*i
    print(b)

