import calendar as cl
cal=cl.prcal(2021)
print(cal)
