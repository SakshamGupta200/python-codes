print("rohit kumar")
print("shree praksh")
print("kusum devi")
print("munari varanasi")
