print("enter your first name=")
n=input()
m=input()
print(n,m)
