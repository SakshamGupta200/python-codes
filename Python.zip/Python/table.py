for i in range(1,15):
    for j in range(1,11):
        print(i*j,"\n")
    print("\n")
