
for i in range (255,0,-1):
    print(chr(i),"-",i,end="\t")
