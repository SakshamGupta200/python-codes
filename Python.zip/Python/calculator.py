from calculator1 import sum
a=int(input("enter your number="))
b=int(input("enter your second number="))
c=calculator1.sum(a,b)
print(c)
