a=input("enter your name")
for i in a:
    if i=='a' or i=='e' or i=='i' or i=='o' or i=='u':
        continue
    print(i,end="")
    
