name={"guddu","munna","falane"}
print(type(name))
print(name)
for i in name:
    print(i)
