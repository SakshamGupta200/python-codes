list1=[]
n=input("enter your msg=")

st=n.split(" ")

for i in st:
    a=len(i)
    if a>3:
        list1.append(i)
        
        
    
    
       
print(list1)

        
