name=set(["guddu","munna","falane","varanasi","ghazipur"])
print(type(name))
print(name)
for i in name:
    print(i)
