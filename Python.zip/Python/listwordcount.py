ab=[]
abc=[]
n=int(input("enter terms="))
print(n)
